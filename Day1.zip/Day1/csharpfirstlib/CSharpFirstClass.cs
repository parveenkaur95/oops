﻿using System;
using csharpfirstlib;

namespace csharpfirstlib
{
    public class CSharpFirstClass
    {


        public static long madd(long firstnum, long secondnum)
        {

            return firstnum + secondnum;
        }
    }
}
