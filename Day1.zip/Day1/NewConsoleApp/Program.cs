﻿using System;
using csharpfirstlib;

namespace NewConsoleApp
{
    class Hello

        //<summary>
        ///
        ///</summary>
    {
        static void Main(string[] args)
        {
           // CSharpFirstClass CSharpobj= new CSharpFirstClass;
            Console.WriteLine(CSharpFirstClass.madd(100,200));
            Console.WriteLine("My first example in c#");
        }
    }
}
