﻿using System;

using Encapsulation;
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int newage;
            int newnum1=30;
            int newnum2=20;
            int month;
            Cperson persobj = new Cperson();
            Cperson persobj1 = new Cperson(231,"Sakshi",20);
            persobj1.AADHARID = 23;
            Console.WriteLine(persobj1.AADHARID);
            Console.WriteLine(persobj1.NAME);
            Console.WriteLine(persobj1.AGE);
            persobj1.mage(out newage);
            Console.WriteLine(newage);
            Console.WriteLine(Cperson.sum(1, 2, 3));
            Console.WriteLine(Cperson.sum(1, 2, 3, 4, 5));
            Console.WriteLine("The values before swap are num1{0}, num2{1}", newnum1, newnum2);

           // Cperson.mSwap(ref newnum1, ref newnum2);

            Cperson.mSwap(num2:ref newnum2, num1:ref newnum1); //to change order of passing arguments

            Console.WriteLine("The values after swap are num1{0}, num2{1}", newnum1, newnum2);
            persobj1.Month = int.Parse(Console.ReadLine());
            Console.WriteLine("value of month"+persobj1.Month);
           // persobj1.Month = 11;

            persobj1.EMAIL = Console.ReadLine();
            Console.WriteLine(persobj1.EMAIL);
            Console.Read();
           
        }
    }
}
