﻿using System;

namespace Encapsulation
{
    public class Cperson
    {
        #region Method

        [Obsolete("This Method is not available in next version of library")]

        public void mage( out int age)
        {
            age = 100;
            Console.WriteLine("age is{0}",_age);
        }

        public static int sum(params int[] param1)
        {

            int val = 0;
            foreach (int P in param1)
            {
                val = val + P;
            }
            return val;
        }

        public static void mSwap(ref int num1, ref int num2)
        {
            //int temp;
            //temp=num1;
            //num1=num2;
            //num2=temp;
            num1=num1+num2;
            num2=num1-num2;
            num1=num1-num2;
        }
       

        #endregion

        #region Property


        public string EMAIL { get; set; }//auto intialized property  
       // public string EMAIL { get; private set; }  makes it read only 
        public int AADHARID
        
        {
            get { return _aadharid; }
            set { _aadharid = value; }
        }

        public String NAME
        {
            get { return _name; }
            set { _name = value; }
        }
        

        public byte AGE
        {
            get { return _age; }
            set { _age = value; }
        }

        
            private int month;
            public int Month
            {
                get
                {
                    return month;
                }
                set
                {
                    if ((value > 0) && (value < 12))
                    {
                        month = value;
                    }
                }
            }
        

        #endregion

        #region Field
        int _aadharid;
        String _name;
        byte _age;
        #endregion

        #region Constructor
        public Cperson()
        {
        }
        public Cperson(int aadharid, String name, byte age)
        {
            this._aadharid = aadharid;
            this._age = age;
            this._name = name;

        }
        #endregion
    }
}
